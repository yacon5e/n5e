import {ClassFeatures} from "./classFeatures.js";

// Namespace Configuration Values
export const NARUTO5E = {};

/**
 * The set of Ability Scores used within the system.
 * @enum {string}
 */
NARUTO5E.abilities = {
  str: "NARUTO5E.AbilityStr",
  dex: "NARUTO5E.AbilityDex",
  con: "NARUTO5E.AbilityCon",
  int: "NARUTO5E.AbilityInt",
  wis: "NARUTO5E.AbilityWis",
  cha: "NARUTO5E.AbilityCha"
};

/**
 * Localized abbreviations for Ability Scores.
 * @enum {string}
 */
NARUTO5E.abilityAbbreviations = {
  str: "NARUTO5E.AbilityStrAbbr",
  dex: "NARUTO5E.AbilityDexAbbr",
  con: "NARUTO5E.AbilityConAbbr",
  int: "NARUTO5E.AbilityIntAbbr",
  wis: "NARUTO5E.AbilityWisAbbr",
  cha: "NARUTO5E.AbilityChaAbbr"
};

/* -------------------------------------------- */

/**
 * Character alignment options.
 * @enum {string}
 */
NARUTO5E.alignments = {
  lg: "NARUTO5E.AlignmentLG",
  ng: "NARUTO5E.AlignmentNG",
  cg: "NARUTO5E.AlignmentCG",
  ln: "NARUTO5E.AlignmentLN",
  tn: "NARUTO5E.AlignmentTN",
  cn: "NARUTO5E.AlignmentCN",
  le: "NARUTO5E.AlignmentLE",
  ne: "NARUTO5E.AlignmentNE",
  ce: "NARUTO5E.AlignmentCE"
};

/* -------------------------------------------- */

/**
 * An enumeration of item attunement types.
 * @enum {number}
 */
NARUTO5E.attunementTypes = {
  NONE: 0,
  REQUIRED: 1,
  ATTUNED: 2
};

/**
 * An enumeration of item attunement states.
 * @type {{"0": string, "1": string, "2": string}}
 */
NARUTO5E.attunements = {
  0: "NARUTO5E.AttunementNone",
  1: "NARUTO5E.AttunementRequired",
  2: "NARUTO5E.AttunementAttuned"
};

/* -------------------------------------------- */

/**
 * General weapon categories.
 * @enum {string}
 */
NARUTO5E.weaponProficiencies = {
  sim: "NARUTO5E.WeaponSimpleProficiency",
  mar: "NARUTO5E.WeaponMartialProficiency",
  web: "NARUTO5E.WeaponWebProficiency",
  bon: "NARUTO5E.WeaponBoneProficiency"
};

/**
 * A mapping between `NARUTO5E.weaponTypes` and `NARUTO5E.weaponProficiencies` that
 * is used to determine if character has proficiency when adding an item.
 * @enum {(boolean|string)}
 */
NARUTO5E.weaponProficienciesMap = {
  natural: true,
  simpleM: "sim",
  simpleR: "sim",
  martialM: "mar",
  martialR: "mar"
};

/**
 * The basic weapon types in 5e. This enables specific weapon proficiencies or
 * starting equipment provided by classes and backgrounds.
 * @enum {string}
 */
NARUTO5E.weaponIds = {
  battleaxe: "I0WocDSuNpGJayPb",
  blowgun: "wNWK6yJMHG9ANqQV",
  club: "nfIRTECQIG81CvM4",
  dagger: "0E565kQUBmndJ1a2",
  dart: "3rCO8MTIdPGSW6IJ",
  flail: "UrH3sMdnUDckIHJ6",
  glaive: "rOG1OM2ihgPjOvFW",
  greataxe: "1Lxk6kmoRhG8qQ0u",
  greatclub: "QRCsxkCwWNwswL9o",
  greatsword: "xMkP8BmFzElcsMaR",
  halberd: "DMejWAc8r8YvDPP1",
  handaxe: "eO7Fbv5WBk5zvGOc",
  handcrossbow: "qaSro7kFhxD6INbZ",
  heavycrossbow: "RmP0mYRn2J7K26rX",
  javelin: "DWLMnODrnHn8IbAG",
  lance: "RnuxdHUAIgxccVwj",
  lightcrossbow: "ddWvQRLmnnIS0eLF",
  lighthammer: "XVK6TOL4sGItssAE",
  longbow: "3cymOVja8jXbzrdT",
  longsword: "10ZP2Bu3vnCuYMIB",
  mace: "Ajyq6nGwF7FtLhDQ",
  maul: "DizirD7eqjh8n95A",
  morningstar: "dX8AxCh9o0A9CkT3",
  net: "aEiM49V8vWpWw7rU",
  pike: "tC0kcqZT9HHAO0PD",
  quarterstaff: "g2dWN7PQiMRYWzyk",
  rapier: "Tobce1hexTnDk4sV",
  scimitar: "fbC0Mg1a73wdFbqO",
  shortsword: "osLzOwQdPtrK3rQH",
  sickle: "i4NeNZ30ycwPDHMx",
  spear: "OG4nBBydvmfWYXIk",
  shortbow: "GJv6WkD7D2J6rP6M",
  sling: "3gynWO9sN4OLGMWD",
  trident: "F65ANO66ckP8FDMa",
  warpick: "2YdfjN1PIIrSHZii",
  warhammer: "F0Df164Xv1gWcYt0",
  whip: "QKTyxoO0YDnAsbYe"
};

/* -------------------------------------------- */

/**
 * The categories into which Tool items can be grouped.
 *
 * @enum {string}
 */
NARUTO5E.toolTypes = {
  art: "NARUTO5E.ToolArtisans",
  game: "NARUTO5E.ToolGamingSet",
  music: "NARUTO5E.ToolMusicalInstrument"
};

/**
 * The categories of tool proficiencies that a character can gain.
 *
 * @enum {string}
 */
NARUTO5E.toolProficiencies = {
  ...NARUTO5E.toolTypes,
  vehicle: "NARUTO5E.ToolVehicle"
};

/**
 * The basic tool types in 5e. This enables specific tool proficiencies or
 * starting equipment provided by classes and backgrounds.
 * @enum {string}
 */
NARUTO5E.toolIds = {
  alchemist: "SztwZhbhZeCqyAes",
  bagpipes: "yxHi57T5mmVt0oDr",
  brewer: "Y9S75go1hLMXUD48",
  calligrapher: "jhjo20QoiD5exf09",
  card: "YwlHI3BVJapz4a3E",
  carpenter: "8NS6MSOdXtUqD7Ib",
  cartographer: "fC0lFK8P4RuhpfaU",
  chess: "23y8FvWKf9YLcnBL",
  cobbler: "hM84pZnpCqKfi8XH",
  cook: "Gflnp29aEv5Lc1ZM",
  dice: "iBuTM09KD9IoM5L8",
  disg: "IBhDAr7WkhWPYLVn",
  drum: "69Dpr25pf4BjkHKb",
  dulcimer: "NtdDkjmpdIMiX7I2",
  flute: "eJOrPcAz9EcquyRQ",
  forg: "cG3m4YlHfbQlLEOx",
  glassblower: "rTbVrNcwApnuTz5E",
  herb: "i89okN7GFTWHsvPy",
  horn: "aa9KuBy4dst7WIW9",
  jeweler: "YfBwELTgPFHmQdHh",
  leatherworker: "PUMfwyVUbtyxgYbD",
  lute: "qBydtUUIkv520DT7",
  lyre: "EwG1EtmbgR3bM68U",
  mason: "skUih6tBvcBbORzA",
  navg: "YHCmjsiXxZ9UdUhU",
  painter: "ccm5xlWhx74d6lsK",
  panflute: "G5m5gYIx9VAUWC3J",
  pois: "il2GNi8C0DvGLL9P",
  potter: "hJS8yEVkqgJjwfWa",
  shawm: "G3cqbejJpfB91VhP",
  smith: "KndVe2insuctjIaj",
  thief: "woWZ1sO5IUVGzo58",
  tinker: "0d08g1i5WXnNrCNA",
  viol: "baoe3U5BfMMMxhCU",
  weaver: "ap9prThUB2y9lDyj",
  woodcarver: "xKErqkLo4ASYr5EP"
};

/* -------------------------------------------- */

/**
 * The various lengths of time over which effects can occur.
 * @enum {string}
 */
NARUTO5E.timePeriods = {
  inst: "NARUTO5E.TimeInst",
  turn: "NARUTO5E.TimeTurn",
  round: "NARUTO5E.TimeRound",
  minute: "NARUTO5E.TimeMinute",
  hour: "NARUTO5E.TimeHour",
  day: "NARUTO5E.TimeDay",
  month: "NARUTO5E.TimeMonth",
  year: "NARUTO5E.TimeYear",
  perm: "NARUTO5E.TimePerm",
  spec: "NARUTO5E.Special"
};

/* -------------------------------------------- */

/**
 * Various ways in which an item or ability can be activated.
 * @enum {string}
 */
NARUTO5E.abilityActivationTypes = {
  none: "NARUTO5E.None",
  action: "NARUTO5E.Action",
  bonus: "NARUTO5E.BonusAction",
  reaction: "NARUTO5E.Reaction",
  minute: NARUTO5E.timePeriods.minute,
  hour: NARUTO5E.timePeriods.hour,
  day: NARUTO5E.timePeriods.day,
  special: NARUTO5E.timePeriods.spec,
  legendary: "NARUTO5E.LegendaryActionLabel",
  lair: "NARUTO5E.LairActionLabel",
  crew: "NARUTO5E.VehicleCrewAction"
};

/* -------------------------------------------- */

/**
 * Different things that an ability can consume upon use.
 * @enum {string}
 */
NARUTO5E.abilityConsumptionTypes = {
  ammo: "NARUTO5E.ConsumeAmmunition",
  attribute: "NARUTO5E.ConsumeAttribute",
  material: "NARUTO5E.ConsumeMaterial",
  charges: "NARUTO5E.ConsumeCharges"
};

/* -------------------------------------------- */

/**
 * Creature sizes.
 * @enum {string}
 */
NARUTO5E.actorSizes = {
  tiny: "NARUTO5E.SizeTiny",
  sm: "NARUTO5E.SizeSmall",
  med: "NARUTO5E.SizeMedium",
  lg: "NARUTO5E.SizeLarge",
  huge: "NARUTO5E.SizeHuge",
  grg: "NARUTO5E.SizeGargantuan"
};

/**
 * Default token image size for the values of `NARUTO5E.actorSizes`.
 * @enum {number}
 */
NARUTO5E.tokenSizes = {
  tiny: 0.5,
  sm: 1,
  med: 1,
  lg: 2,
  huge: 3,
  grg: 4
};

/**
 * Colors used to visualize temporary and temporary maximum HP in token health bars.
 * @enum {number}
 */
NARUTO5E.tokenHPColors = {
  damage: 0xFF0000,
  healing: 0x00FF00,
  temp: 0x66CCFF,
  tempmax: 0x440066,
  negmax: 0x550000
};

/* -------------------------------------------- */

/**
 * Default types of creatures.
 * @enum {string}
 */
NARUTO5E.creatureTypes = {
  aberration: "NARUTO5E.CreatureAberration",
  beast: "NARUTO5E.CreatureBeast",
  celestial: "NARUTO5E.CreatureCelestial",
  construct: "NARUTO5E.CreatureConstruct",
  dragon: "NARUTO5E.CreatureDragon",
  elemental: "NARUTO5E.CreatureElemental",
  fey: "NARUTO5E.CreatureFey",
  fiend: "NARUTO5E.CreatureFiend",
  giant: "NARUTO5E.CreatureGiant",
  humanoid: "NARUTO5E.CreatureHumanoid",
  monstrosity: "NARUTO5E.CreatureMonstrosity",
  ooze: "NARUTO5E.CreatureOoze",
  plant: "NARUTO5E.CreaturePlant",
  undead: "NARUTO5E.CreatureUndead"
};

/* -------------------------------------------- */

/**
 * Classification types for item action types.
 * @enum {string}
 */
NARUTO5E.itemActionTypes = {
  mwak: "NARUTO5E.ActionMWAK",
  rwak: "NARUTO5E.ActionRWAK",
  msak: "NARUTO5E.ActionMSAK",
  rsak: "NARUTO5E.ActionRSAK",
  save: "NARUTO5E.ActionSave",
  heal: "NARUTO5E.ActionHeal",
  abil: "NARUTO5E.ActionAbil",
  util: "NARUTO5E.ActionUtil",
  other: "NARUTO5E.ActionOther"
};

/* -------------------------------------------- */

/**
 * Different ways in which item capacity can be limited.
 * @enum {string}
 */
NARUTO5E.itemCapacityTypes = {
  items: "NARUTO5E.ItemContainerCapacityItems",
  weight: "NARUTO5E.ItemContainerCapacityWeight"
};

/* -------------------------------------------- */

/**
 * List of various item rarities.
 * @enum {string}
 */
NARUTO5E.itemRarity = {
  common: "NARUTO5E.ItemRarityCommon",
  uncommon: "NARUTO5E.ItemRarityUncommon",
  rare: "NARUTO5E.ItemRarityRare",
  veryRare: "NARUTO5E.ItemRarityVeryRare",
  legendary: "NARUTO5E.ItemRarityLegendary",
  artifact: "NARUTO5E.ItemRarityArtifact"
};

/* -------------------------------------------- */

/**
 * Enumerate the lengths of time over which an item can have limited use ability.
 * @enum {string}
 */
NARUTO5E.limitedUsePeriods = {
  sr: "NARUTO5E.ShortRest",
  lr: "NARUTO5E.LongRest",
  day: "NARUTO5E.Day",
  charges: "NARUTO5E.Charges"
};

/* -------------------------------------------- */

/**
 * Specific equipment types that modify base AC.
 * @enum {string}
 */
NARUTO5E.armorTypes = {
  light: "NARUTO5E.EquipmentLight",
  medium: "NARUTO5E.EquipmentMedium",
  heavy: "NARUTO5E.EquipmentHeavy",
  natural: "NARUTO5E.EquipmentNatural",
  shield: "NARUTO5E.EquipmentShield"
};

/* -------------------------------------------- */

/**
 * Equipment types that aren't armor.
 * @enum {string}
 */
NARUTO5E.miscEquipmentTypes = {
  clothing: "NARUTO5E.EquipmentClothing",
  trinket: "NARUTO5E.EquipmentTrinket",
  vehicle: "NARUTO5E.EquipmentVehicle"
};

/* -------------------------------------------- */

/**
 * The set of equipment types for armor, clothing, and other objects which can be worn by the character.
 * @enum {string}
 */
NARUTO5E.equipmentTypes = {
  ...NARUTO5E.miscEquipmentTypes,
  ...NARUTO5E.armorTypes
};

/* -------------------------------------------- */

/**
 * The various types of vehicles in which characters can be proficient.
 * @enum {string}
 */
NARUTO5E.vehicleTypes = {
  air: "NARUTO5E.VehicleTypeAir",
  land: "NARUTO5E.VehicleTypeLand",
  water: "NARUTO5E.VehicleTypeWater"
};

/* -------------------------------------------- */

/**
 * The set of Armor Proficiencies which a character may have.
 * @type {object}
 */
NARUTO5E.armorProficiencies = {
  lgt: NARUTO5E.equipmentTypes.light,
  med: NARUTO5E.equipmentTypes.medium,
  hvy: NARUTO5E.equipmentTypes.heavy,
  shl: "NARUTO5E.EquipmentShieldProficiency"
};

/**
 * A mapping between `NARUTO5E.equipmentTypes` and `NARUTO5E.armorProficiencies` that
 * is used to determine if character has proficiency when adding an item.
 * @enum {(boolean|string)}
 */
NARUTO5E.armorProficienciesMap = {
  natural: true,
  clothing: true,
  light: "lgt",
  medium: "med",
  heavy: "hvy",
  shield: "shl"
};

/**
 * The basic armor types in 5e. This enables specific armor proficiencies,
 * automated AC calculation in NPCs, and starting equipment.
 * @enum {string}
 */
NARUTO5E.armorIds = {
  breastplate: "SK2HATQ4abKUlV8i",
  chainmail: "rLMflzmxpe8JGTOA",
  chainshirt: "p2zChy24ZJdVqMSH",
  halfplate: "vsgmACFYINloIdPm",
  hide: "n1V07puo0RQxPGuF",
  leather: "WwdpHLXGX5r8uZu5",
  padded: "GtKV1b5uqFQqpEni",
  plate: "OjkIqlW2UpgFcjZa",
  ringmail: "nsXZejlmgalj4he9",
  scalemail: "XmnlF5fgIO3tg6TG",
  splint: "cKpJmsJmU8YaiuqG",
  studded: "TIV3B1vbrVHIhQAm"
};

/**
 * The basic shield in 5e.
 * @enum {string}
 */
NARUTO5E.shieldIds = {
  shield: "sSs3hSzkKBMNBgTs"
};

/**
 * Common armor class calculations.
 * @enum {{ label: string, [formula]: string }}
 */
NARUTO5E.armorClasses = {
  default: {
    label: "NARUTO5E.ArmorClassSkin",
    formula: "10 + floor(@prof/2) + @abilities.dex.mod"
  },
  skin: {
    label: "NARUTO5E.ArmorClassSkin",
    formula: "10 + floor(@prof/2) + @abilities.dex.mod"
  },
  shark: {
    label: "NARUTO5E.ArmorClassSharkSkin",
    formula: "10 + floor(@prof/2) + @abilities.con.mod"
  },
  psycha: {
    label: "NARUTO5E.ArmorClassPsyCha",
    formula: "10 + floor(@prof/2) + @abilities.cha.mod"
  },
   psywis: {
    label: "NARUTO5E.ArmorClassPsyWis",
    formula: "10 + floor(@prof/2) + @abilities.wis.mod"
  },
   evasive: {
    label: "NARUTO5E.ArmorClassEvasive",
    formula: "10 + @prof + @abilities.dex.mod"
  },
   geo: {
    label: "NARUTO5E.ArmorClassGeo",
    formula: "13 + floor(@prof/2) + @abilities.con.mod"
  },
   sharingan: {
    label: "NARUTO5E.ArmorClassSharingan",
    formula: "10 + floor(@prof/2) + @abilities.dex.mod + @abilities.int.mod"
  },
   bone: {
    label: "NARUTO5E.ArmorClassBone",
    formula: "10 + floor(@prof/2) + @abilities.dex.mod + @abilities.con.mod"
  },
   unarmored: {
    label: "NARUTO5E.ArmorClassUnarmored",
    formula: "10 + floor(@prof/2) + @abilities.dex.mod + @abilities.wis.mod"
  },
  custom: {
    label: "NARUTO5E.ArmorClassCustom"
  }
};

/* -------------------------------------------- */

/**
 * Enumerate the valid consumable types which are recognized by the system.
 * @enum {string}
 */
NARUTO5E.consumableTypes = {
  ammo: "NARUTO5E.ConsumableAmmunition",
  potion: "NARUTO5E.ConsumablePotion",
  poison: "NARUTO5E.ConsumablePoison",
  food: "NARUTO5E.ConsumableFood",
  scroll: "NARUTO5E.ConsumableScroll",
  wand: "NARUTO5E.ConsumableWand",
  rod: "NARUTO5E.ConsumableRod",
  trinket: "NARUTO5E.ConsumableTrinket"
};

/* -------------------------------------------- */

/**
 * The valid currency denominations with localized labels, abbreviations, and conversions.
 * @enum {{
 *   label: string,
 *   abbreviation: string,
 *   [conversion]: {into: string, each: number}
 * }}
 */
NARUTO5E.currencies = {
  ryo: {
    label: "NARUTO5E.CurrencyRYO",
    abbreviation: "NARUTO5E.CurrencyAbbrRYO"
  },
  gp: {
    label: "NARUTO5E.CurrencyGP",
    abbreviation: "NARUTO5E.CurrencyAbbrGP",
    conversion: {into: "pp", each: 10}
  },
  ep: {
    label: "NARUTO5E.CurrencyEP",
    abbreviation: "NARUTO5E.CurrencyAbbrEP",
    conversion: {into: "gp", each: 2}
  },
  sp: {
    label: "NARUTO5E.CurrencySP",
    abbreviation: "NARUTO5E.CurrencyAbbrSP",
    conversion: {into: "ep", each: 5}
  },
  cp: {
    label: "NARUTO5E.CurrencyCP",
    abbreviation: "NARUTO5E.CurrencyAbbrCP",
    conversion: {into: "sp", each: 10}
  }
};

/* -------------------------------------------- */

/**
 * Types of damage the can be caused by abilities.
 * @enum {string}
 */
NARUTO5E.damageTypes = {
  acid: "NARUTO5E.DamageAcid",
  bludgeoning: "NARUTO5E.DamageBludgeoning",
  cold: "NARUTO5E.DamageCold",
  chakra: "NARUTO5E.DamageChakra",
  earth: "NARUTO5E.DamageEarth",
  fire: "NARUTO5E.DamageFire",
  force: "NARUTO5E.DamageForce",
  lightning: "NARUTO5E.DamageLightning",
  necrotic: "NARUTO5E.DamageNecrotic",
  piercing: "NARUTO5E.DamagePiercing",
  poison: "NARUTO5E.DamagePoison",
  psychic: "NARUTO5E.DamagePsychic",
  slashing: "NARUTO5E.DamageSlashing",
  wind: "NARUTO5E.DamageWind"
};

/**
 * Types of damage to which an actor can possess resistance, immunity, or vulnerability.
 * @enum {string}
 */
NARUTO5E.damageResistanceTypes = {
  ...NARUTO5E.damageTypes,
  physical: "NARUTO5E.DamagePhysical"
};

/* -------------------------------------------- */

/**
 * The valid units of measure for movement distances in the game system.
 * By default this uses the imperial units of feet and miles.
 * @enum {string}
 */
NARUTO5E.movementTypes = {
  burrow: "NARUTO5E.MovementBurrow",
  climb: "NARUTO5E.MovementClimb",
  fly: "NARUTO5E.MovementFly",
  swim: "NARUTO5E.MovementSwim",
  walk: "NARUTO5E.MovementWalk"
};

/**
 * The valid units of measure for movement distances in the game system.
 * By default this uses the imperial units of feet and miles.
 * @enum {string}
 */
NARUTO5E.movementUnits = {
  ft: "NARUTO5E.DistFt",
  mi: "NARUTO5E.DistMi",
  m: "NARUTO5E.DistM",
  km: "NARUTO5E.DistKm"
};

/**
 * The valid units of measure for the range of an action or effect.
 * This object automatically includes the movement units from `NARUTO5E.movementUnits`.
 * @enum {string}
 */
NARUTO5E.distanceUnits = {
  none: "NARUTO5E.None",
  self: "NARUTO5E.DistSelf",
  touch: "NARUTO5E.DistTouch",
  spec: "NARUTO5E.Special",
  any: "NARUTO5E.DistAny",
  ...NARUTO5E.movementUnits
};

/* -------------------------------------------- */

/**
 * Configure aspects of encumbrance calculation so that it could be configured by modules.
 * @enum {{ imperial: number, metric: number }}
 */
NARUTO5E.encumbrance = {
  currencyPerWeight: {
    imperial: 50,
    metric: 110
  },
  strMultiplier: {
    imperial: 15,
    metric: 6.8
  },
  vehicleWeightMultiplier: {
    imperial: 2000, // 2000 lbs in an imperial ton
    metric: 1000 // 1000 kg in a metric ton
  }
};

/* -------------------------------------------- */

/**
 * The types of single or area targets which can be applied to abilities.
 * @enum {string}
 */
NARUTO5E.targetTypes = {
  none: "NARUTO5E.None",
  self: "NARUTO5E.TargetSelf",
  creature: "NARUTO5E.TargetCreature",
  ally: "NARUTO5E.TargetAlly",
  enemy: "NARUTO5E.TargetEnemy",
  object: "NARUTO5E.TargetObject",
  space: "NARUTO5E.TargetSpace",
  radius: "NARUTO5E.TargetRadius",
  sphere: "NARUTO5E.TargetSphere",
  cylinder: "NARUTO5E.TargetCylinder",
  cone: "NARUTO5E.TargetCone",
  square: "NARUTO5E.TargetSquare",
  cube: "NARUTO5E.TargetCube",
  line: "NARUTO5E.TargetLine",
  wall: "NARUTO5E.TargetWall"
};

/* -------------------------------------------- */

/**
 * Mapping between `NARUTO5E.targetTypes` and `MeasuredTemplate` shape types to define
 * which templates are produced by which area of effect target type.
 * @enum {string}
 */
NARUTO5E.areaTargetTypes = {
  cone: "cone",
  cube: "rect",
  cylinder: "circle",
  line: "ray",
  radius: "circle",
  sphere: "circle",
  square: "rect",
  wall: "ray"
};

/* -------------------------------------------- */

/**
 * Different types of healing that can be applied using abilities.
 * @enum {string}
 */
NARUTO5E.healingTypes = {
  healing: "NARUTO5E.Healing",
  temphp: "NARUTO5E.HealingTemp"
};

/* -------------------------------------------- */

/**
 * Denominations of hit dice which can apply to classes.
 * @type {string[]}
 */
NARUTO5E.hitDieTypes = ["d6", "d8", "d10", "d12"];
NARUTO5E.chakraDieTypes = ["d6", "d8", "d10", "d12"];

/* -------------------------------------------- */

/**
 * The set of possible sensory perception types which an Actor may have.
 * @enum {string}
 */
NARUTO5E.senses = {
  blindsight: "NARUTO5E.SenseBlindsight",
  darkvision: "NARUTO5E.SenseDarkvision",
  tremorsense: "NARUTO5E.SenseTremorsense",
  truesight: "NARUTO5E.SenseTruesight",
  chakrasight: "NARUTO5E.SenseChakrasight"
};

/* -------------------------------------------- */

/**
 * The set of skill which can be trained.
 * @enum {string}
 */
NARUTO5E.skills = {
  acr: "NARUTO5E.SkillAcr",
  ani: "NARUTO5E.SkillAni",
  ath: "NARUTO5E.SkillAth",
  cha: "NARUTO5E.SkillCha",
  cra: "NARUTO5E.SkillCra",
  dec: "NARUTO5E.SkillDec",
  ill: "NARUTO5E.SkillIll",
  his: "NARUTO5E.SkillHis",
  ins: "NARUTO5E.SkillIns",
  itm: "NARUTO5E.SkillItm",
  inv: "NARUTO5E.SkillInv",
  med: "NARUTO5E.SkillMed",
  nat: "NARUTO5E.SkillNat",
  nin: "NARUTO5E.SkillNin",
  prc: "NARUTO5E.SkillPrc",
  prf: "NARUTO5E.SkillPrf",
  per: "NARUTO5E.SkillPer",
  slt: "NARUTO5E.SkillSlt",
  ste: "NARUTO5E.SkillSte",
  sur: "NARUTO5E.SkillSur",
  mar: "NARUTO5E.SkillMar",
};

/* -------------------------------------------- */

/**
 * Various different ways a spell can be prepared.
 */
NARUTO5E.spellPreparationModes = {
  prepared: "NARUTO5E.SpellPrepPrepared",
  pact: "NARUTO5E.PactMagic",
  always: "NARUTO5E.SpellPrepAlways",
  atwill: "NARUTO5E.SpellPrepAtWill",
  innate: "NARUTO5E.SpellPrepInnate"
};

/**
 * Subset of `NARUTO5E.spellPreparationModes` that consume spell slots.
 * @type {boolean[]}
 */
NARUTO5E.spellUpcastModes = ["always", "pact", "prepared"];

/**
 * Ways in which a class can contribute to spellcasting levels.
 * @enum {string}
 */
NARUTO5E.spellProgression = {
  none: "NARUTO5E.SpellNone",
  full: "NARUTO5E.SpellProgFull",
  half: "NARUTO5E.SpellProgHalf",
  third: "NARUTO5E.SpellProgThird",
  pact: "NARUTO5E.SpellProgPact",
  artificer: "NARUTO5E.SpellProgArt"
};

/* -------------------------------------------- */

/**
 * The available choices for how spell damage scaling may be computed.
 * @enum {string}
 */
NARUTO5E.spellScalingModes = {
  none: "NARUTO5E.SpellNone",
  cantrip: "NARUTO5E.SpellCantrip",
  level: "NARUTO5E.SpellLevel"
};

/* -------------------------------------------- */

/**
 * The set of types which a weapon item can take.
 * @enum {string}
 */
NARUTO5E.weaponTypes = {
  simpleM: "NARUTO5E.WeaponSimpleM",
  simpleR: "NARUTO5E.WeaponSimpleR",
  martialM: "NARUTO5E.WeaponMartialM",
  martialR: "NARUTO5E.WeaponMartialR",
  natural: "NARUTO5E.WeaponNatural",
  improv: "NARUTO5E.WeaponImprov",
  siege: "NARUTO5E.WeaponSiege"
};

/* -------------------------------------------- */

/**
 * The set of weapon property flags which can exist on a weapon.
 * @enum {string}
 */
NARUTO5E.weaponProperties = {
  ada: "NARUTO5E.WeaponPropertiesAda",
  amm: "NARUTO5E.WeaponPropertiesAmm",
  fin: "NARUTO5E.WeaponPropertiesFin",
  fir: "NARUTO5E.WeaponPropertiesFir",
  foc: "NARUTO5E.WeaponPropertiesFoc",
  hvy: "NARUTO5E.WeaponPropertiesHvy",
  lgt: "NARUTO5E.WeaponPropertiesLgt",
  lod: "NARUTO5E.WeaponPropertiesLod",
  mgc: "NARUTO5E.WeaponPropertiesMgc",
  rch: "NARUTO5E.WeaponPropertiesRch",
  rel: "NARUTO5E.WeaponPropertiesRel",
  ret: "NARUTO5E.WeaponPropertiesRet",
  sil: "NARUTO5E.WeaponPropertiesSil",
  spc: "NARUTO5E.WeaponPropertiesSpc",
  thr: "NARUTO5E.WeaponPropertiesThr",
  two: "NARUTO5E.WeaponPropertiesTwo",
  ver: "NARUTO5E.WeaponPropertiesVer"
};

/**
 * Types of components that can be required when casting a spell.
 * @enum {string}
 */
NARUTO5E.spellComponents = {
  V: "NARUTO5E.ComponentVerbal",
  S: "NARUTO5E.ComponentSomatic",
  MA: "NARUTO5E.ComponentMaterial",
  CS: "NARUTO5E.ComponentChakraseals",
  HS: "NARUTO5E.ComponentHandseals",
  M: "NARUTO5E.ComponentMobility",
  CM: "NARUTO5E.ComponentMolding",
  W: "NARUTO5E.ComponentWeapon",
  NT: "NARUTO5E.ComponentNinjatool",
  MED: "NARUTO5E.ComponentMedical",
  FUIN: "NARUTO5E.ComponentFuinjutsu",
  SENS: "NARUTO5E.ComponentSensory",
  CLASH: "NARUTO5E.ComponentClash"
};

/**
 * Schools to which a spell can belong.
 * @enum {string}
 */
NARUTO5E.spellSchools = {
  abj: "NARUTO5E.SchoolAbj",
  con: "NARUTO5E.SchoolCon",
  div: "NARUTO5E.SchoolDiv",
  enc: "NARUTO5E.SchoolEnc",
  evo: "NARUTO5E.SchoolEvo",
  ill: "NARUTO5E.SchoolIll"
};

/**
 * Valid spell levels.
 * @enum {string}
 */
NARUTO5E.spellLevels = {
  0: "NARUTO5E.SpellLevel0",
  1: "NARUTO5E.SpellLevel1",
  2: "NARUTO5E.SpellLevel2",
  3: "NARUTO5E.SpellLevel3",
  4: "NARUTO5E.SpellLevel4",
  5: "NARUTO5E.SpellLevel5",
  6: "NARUTO5E.SpellLevel6",
  7: "NARUTO5E.SpellLevel7",
  8: "NARUTO5E.SpellLevel8",
  9: "NARUTO5E.SpellLevel9",
  10: "NARUTO5E.SpellLevel10"
};

/**
 * Spell scroll item ID within the `NARUTO5E.sourcePacks` compendium for each level.
 * @enum {string}
 */
NARUTO5E.spellScrollIds = {
  0: "rQ6sO7HDWzqMhSI3",
  1: "9GSfMg0VOA2b4uFN",
  2: "XdDp6CKh9qEvPTuS",
  3: "hqVKZie7x9w3Kqds",
  4: "DM7hzgL836ZyUFB1",
  5: "wa1VF8TXHmkrrR35",
  6: "tI3rWx4bxefNCexS",
  7: "mtyw4NS1s7j2EJaD",
  8: "aOrinPg7yuDZEuWr",
  9: "O4YbkJkLlnsgUszZ"
};

/**
 * Compendium packs used for localized items.
 * @enum {string}
 */
NARUTO5E.sourcePacks = {
  ITEMS: "naruto5e.items"
};

/**
 * Define the standard slot progression by character level.
 * The entries of this array represent the spell slot progression for a full spell-caster.
 * @type {number[][]}
 */
NARUTO5E.SPELL_SLOT_TABLE = [
  [1],
  [3],
  [4, 2],
  [4, 3],
  [4, 3, 2],
  [4, 3, 3],
  [4, 3, 3, 1],
  [4, 3, 3, 2],
  [4, 3, 3, 3, 1],
  [4, 3, 3, 3, 2],
  [4, 3, 3, 3, 2, 1],
  [4, 3, 3, 3, 2, 1],
  [4, 3, 3, 3, 2, 1, 1],
  [4, 3, 3, 3, 2, 1, 1],
  [4, 3, 3, 3, 2, 1, 1, 1],
  [4, 3, 3, 3, 2, 1, 1, 1],
  [4, 3, 3, 3, 2, 1, 1, 1, 1],
  [4, 3, 3, 3, 3, 1, 1, 1, 1],
  [4, 3, 3, 3, 3, 2, 1, 1, 1],
  [4, 3, 3, 3, 3, 2, 2, 1, 1]
];

/* -------------------------------------------- */

/**
 * Settings to configure how actors are merged when polymorphing is applied.
 * @enum {string}
 */
NARUTO5E.polymorphSettings = {
  keepPhysical: "NARUTO5E.PolymorphKeepPhysical",
  keepMental: "NARUTO5E.PolymorphKeepMental",
  keepSaves: "NARUTO5E.PolymorphKeepSaves",
  keepSkills: "NARUTO5E.PolymorphKeepSkills",
  mergeSaves: "NARUTO5E.PolymorphMergeSaves",
  mergeSkills: "NARUTO5E.PolymorphMergeSkills",
  keepClass: "NARUTO5E.PolymorphKeepClass",
  keepFeats: "NARUTO5E.PolymorphKeepFeats",
  keepSpells: "NARUTO5E.PolymorphKeepSpells",
  keepItems: "NARUTO5E.PolymorphKeepItems",
  keepBio: "NARUTO5E.PolymorphKeepBio",
  keepVision: "NARUTO5E.PolymorphKeepVision"
};

/* -------------------------------------------- */

/**
 * Skill, ability, and tool proficiency levels.
 * The key for each level represents its proficiency multiplier.
 * @enum {string}
 */
NARUTO5E.proficiencyLevels = {
  0: "NARUTO5E.NotProficient",
  1: "NARUTO5E.Proficient",
  0.5: "NARUTO5E.HalfProficient",
  2: "NARUTO5E.Expertise"
};

/* -------------------------------------------- */

/**
 * The amount of cover provided by an object. In cases where multiple pieces
 * of cover are in play, we take the highest value.
 * @enum {string}
 */
NARUTO5E.cover = {
  0: "NARUTO5E.None",
  .5: "NARUTO5E.CoverHalf",
  .75: "NARUTO5E.CoverThreeQuarters",
  1: "NARUTO5E.CoverTotal"
};

/* -------------------------------------------- */

/**
 * A selection of actor attributes that can be tracked on token resource bars.
 * @type {string[]}
 */
NARUTO5E.trackableAttributes = [
  "attributes.ac.value", "attributes.init.value", "attributes.movement", "attributes.senses", "attributes.spelldc",
  "attributes.spellLevel", "details.cr", "details.spellLevel", "details.xp.value", "skills.*.passive",
  "abilities.*.value"
];

/* -------------------------------------------- */

/**
 * A selection of actor and item attributes that are valid targets for item resource consumption.
 * @type {string[]}
 */
NARUTO5E.consumableResources = [
  "item.quantity", "item.weight", "item.duration.value", "currency", "details.xp.value", "abilities.*.value",
  "attributes.senses", "attributes.movement", "attributes.ac.flat", "item.armor.value", "item.target", "item.range",
  "item.save.dc"
];

/* -------------------------------------------- */

/**
 * Conditions that can effect an actor.
 * @enum {string}
 */
NARUTO5E.conditionTypes = {
  berserk: "NARUTO5E.ConBerserk",
  bleeding: "NARUTO5E.ConBleeding",
  blinded: "NARUTO5E.ConBlinded",
  burned: "NARUTO5E.ConBurned",
  charmed: "NARUTO5E.ConCharmed",
  chilled: "NARUTO5E.ConChilled",
  corroed: "NARUTO5E.ConCorroed",
  dazed: "NARUTO5E.ConDazed",
  deafened: "NARUTO5E.ConDeafened",
  envenomed: "NARUTO5E.ConEnvenomed",
  exhaustion: "NARUTO5E.ConExhaustion",
  frightened: "NARUTO5E.ConFrightened",
  grappled: "NARUTO5E.ConGrappled",
  incapacitated: "NARUTO5E.ConIncapacitated",
  invisible: "NARUTO5E.ConInvisible",
  paralyzed: "NARUTO5E.ConParalyzed",
  petrified: "NARUTO5E.ConPetrified",
  poisoned: "NARUTO5E.ConPoisoned",
  prone: "NARUTO5E.ConProne",
  restrained: "NARUTO5E.ConRestrained",
  shocked: "NARUTO5E.ConShocked",
  slowed: "NARUTO5E.ConSlowed",
  stunned: "NARUTO5E.ConStunned",
  unconscious: "NARUTO5E.ConUnconscious",
  weakened: "NARUTO5E.ConWeakened",
};

/**
 * Languages a character can learn.
 * @enum {string}
 */
NARUTO5E.languages = {
  common: "NARUTO5E.LanguagesCommon",
  firedialect: "NARUTO5E.LanguagesFiredialect",
  earthdialect: "NARUTO5E.LanguagesEarthdialect",
  waterdialect: "NARUTO5E.LanguagesWaterdialect",
  clouddialect: "NARUTO5E.LanguagesClouddialect",
  sanddialect: "NARUTO5E.LanguagesSanddialect",
  snakedialect: "NARUTO5E.LanguagesSnakedialect",
  insectdialect: "NARUTO5E.LanguagesInsectdialectc",
  dogdialect: "NARUTO5E.LanguagesDogdialectc"
};

/**
 * XP required to achieve each character level.
 * @type {number[]}
 */
NARUTO5E.CHARACTER_EXP_LEVELS = [
  0, 300, 900, 2700, 6500, 14000, 23000, 34000, 48000, 64000, 85000, 100000,
  120000, 140000, 165000, 195000, 225000, 265000, 305000, 355000
];

/**
 * XP granted for each challenge rating.
 * @type {number[]}
 */
NARUTO5E.CR_EXP_LEVELS = [
  10, 200, 450, 700, 1100, 1800, 2300, 2900, 3900, 5000, 5900, 7200, 8400, 10000, 11500, 13000, 15000, 18000,
  20000, 22000, 25000, 33000, 41000, 50000, 62000, 75000, 90000, 105000, 120000, 135000, 155000
];

/**
 * Character features automatically granted by classes & subclasses at certain levels.
 * @type {object}
 */
NARUTO5E.classFeatures = ClassFeatures;

/**
 * Special character flags.
 * @enum {{
 *   name: string,
 *   hint: string,
 *   [abilities]: string[],
 *   [skills]: string[],
 *   section: string,
 *   type: any,
 *   placeholder: any
 * }}
 */
NARUTO5E.characterFlags = {
  diamondSoul: {
    name: "NARUTO5E.FlagsDiamondSoul",
    hint: "NARUTO5E.FlagsDiamondSoulHint",
    section: "NARUTO5E.Feats",
    type: Boolean
  },
  elvenAccuracy: {
    name: "NARUTO5E.FlagsElvenAccuracy",
    hint: "NARUTO5E.FlagsElvenAccuracyHint",
    section: "NARUTO5E.RacialTraits",
    type: Boolean
  },
  halflingLucky: {
    name: "NARUTO5E.FlagsHalflingLucky",
    hint: "NARUTO5E.FlagsHalflingLuckyHint",
    section: "NARUTO5E.RacialTraits",
    type: Boolean
  },
  initiativeAdv: {
    name: "NARUTO5E.FlagsInitiativeAdv",
    hint: "NARUTO5E.FlagsInitiativeAdvHint",
    section: "NARUTO5E.Feats",
    type: Boolean
  },
  initiativeAlert: {
    name: "NARUTO5E.FlagsAlert",
    hint: "NARUTO5E.FlagsAlertHint",
    section: "NARUTO5E.Feats",
    type: Boolean
  },
  jackOfAllTrades: {
    name: "NARUTO5E.FlagsJOAT",
    hint: "NARUTO5E.FlagsJOATHint",
    section: "NARUTO5E.Feats",
    type: Boolean
  },
  observantFeat: {
    name: "NARUTO5E.FlagsObservant",
    hint: "NARUTO5E.FlagsObservantHint",
    skills: ["prc", "inv"],
    section: "NARUTO5E.Feats",
    type: Boolean
  },
  powerfulBuild: {
    name: "NARUTO5E.FlagsPowerfulBuild",
    hint: "NARUTO5E.FlagsPowerfulBuildHint",
    section: "NARUTO5E.RacialTraits",
    type: Boolean
  },
  reliableTalent: {
    name: "NARUTO5E.FlagsReliableTalent",
    hint: "NARUTO5E.FlagsReliableTalentHint",
    section: "NARUTO5E.Feats",
    type: Boolean
  },
  remarkableAthlete: {
    name: "NARUTO5E.FlagsRemarkableAthlete",
    hint: "NARUTO5E.FlagsRemarkableAthleteHint",
    abilities: ["str", "dex", "con"],
    section: "NARUTO5E.Feats",
    type: Boolean
  },
  weaponCriticalThreshold: {
    name: "NARUTO5E.FlagsWeaponCritThreshold",
    hint: "NARUTO5E.FlagsWeaponCritThresholdHint",
    section: "NARUTO5E.Feats",
    type: Number,
    placeholder: 20
  },
  spellCriticalThreshold: {
    name: "NARUTO5E.FlagsSpellCritThreshold",
    hint: "NARUTO5E.FlagsSpellCritThresholdHint",
    section: "NARUTO5E.Feats",
    type: Number,
    placeholder: 20
  },
  meleeCriticalDamageDice: {
    name: "NARUTO5E.FlagsMeleeCriticalDice",
    hint: "NARUTO5E.FlagsMeleeCriticalDiceHint",
    section: "NARUTO5E.Feats",
    type: Number,
    placeholder: 0
  }
};

/**
 * Flags allowed on actors. Any flags not in the list may be deleted during a migration.
 * @type {string[]}
 */
NARUTO5E.allowedActorFlags = ["isPolymorphed", "originalActor"].concat(Object.keys(NARUTO5E.characterFlags));
